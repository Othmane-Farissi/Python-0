# ft_package
A sample test package to count occurrences in a list.

## CMD to create package:

python3 -m pip install --upgrade build

