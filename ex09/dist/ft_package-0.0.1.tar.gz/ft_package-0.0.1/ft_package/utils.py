def count_in_list(lst, value):
    """
    Count how many times `value` appears in `lst`.
    """
    return lst.count(value)
